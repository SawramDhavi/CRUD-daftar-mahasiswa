<?php  
session_start();

if (!isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}

?>
<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,900;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="style.css">

  <title>Profile</title>
</head>
<body>
  <div class="container">
   <div class="card mb-3 kartu">
    <div class="row g-0">
      <div class="col-md-6 text">
        <div class="card-body">
          <br>
          <h1 class="card-title animate__animated animate__jackInTheBox">Halo semuanya, perkenalkan nama saya <span>Sawram Dhavi</span></h1>
          <br>
          <p class="card-text animate__animated animate__jackInTheBox">Anda bisa memanggil saya dhavi. Saat ini saya sedang menempuh pendidikan di Universitas Gunadarma, 
            mengambil D3 jurusan Manajemen Informatika. Salam kenal, terima kasih telah mengunjungi website ini, 
            silahkan kirimkan kritik dan saran tentang website yang saya buat. <br><br><a href="index.php">Halaman utama</a></p>
          </div>
        </div>
        <div class="col-md-6">
          <img src="img/man.jpg" style="width: 460px;">
        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
  -->
</body>
</html>