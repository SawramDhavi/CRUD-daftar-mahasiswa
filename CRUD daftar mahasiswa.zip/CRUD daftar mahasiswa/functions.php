<?php   
// koneksi ke database
// nama hostnya, username : root, password : kosong, nama database
$conn = mysqli_connect("localhost", "root", "", "diphpin");
// $conn = mysqli_connect("localhost", "id15795599_php", "Mesqueunclub10.", "id15795599_diphpin");

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;

	}
	return $rows;
}

function tambah($data) {
	global $conn;

	$npm = htmlspecialchars($data["npm"]);
	$nama = htmlspecialchars($data["nama"]);
	$email = htmlspecialchars($data["email"]);
	$jurusan = htmlspecialchars($data["jurusan"]);
	
	// upload gambar
	$gambar = upload();
	if (!$gambar) {
		return false;
	}


	$query = "INSERT INTO mahasiswa 
	VALUES
	(null, '$npm', '$nama', '$email', '$jurusan', '$gambar')
	";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function upload() {
	$namaFile =  $_FILES['gambar']['name'];
	$ukuranFile = $_FILES['gambar']['size'];
	$error = $_FILES['gambar']['error'];
	$tmpName = $_FILES['gambar']['tmp_name'];

	// cek apakah tidak ada gambar yg diupload
	if ($error === 4) {
		echo "<script>
			 	alert('pilih gambar terlebih dahulu!');
			  </script>";
		return false;
	}

	// cek yg diupload gambar atau bukan
	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if ( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
		echo "<script>
			 	alert('Yang anda upload bukan gambar');
			  </script>";
		return false;
	}

	// cek jika ukurannya terlalu besar 
	if ($ukuranFile > 8000000) {
		echo "<script>
			 	alert('ukuran gambar terlalu besar');
			  </script>";
		return false;
	}

	// lolos pengecekan gambar siap di upload
	// generate nama gambar baru jika ada yg upload namanya sama
	$namaFileBaru = uniqid();
	$namaFileBaru.= '.';
	$namaFileBaru.= $ekstensiGambar;


	move_uploaded_file($tmpName, 'img/'. $namaFileBaru);

	return $namaFileBaru;

}



function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM mahasiswa WHERE id = $id");

	return mysqli_affected_rows($conn);
}

function ubah($data) {
	global $conn;
	$id = $data["id"];
	$npm = htmlspecialchars($data["npm"]);
	$nama = htmlspecialchars($data["nama"]);
	$email = htmlspecialchars($data["email"]);
	$jurusan = htmlspecialchars($data["jurusan"]);
	$gambarLama = htmlspecialchars($data["gambarLama"]);

	// cek apakah user pilih gambar baru atau tidak
	if ($_FILES['gambar']['error'] === 4) {
		$gambar = $gambarLama;
	} else {
		$gambar = upload();
	}

	$query = "UPDATE mahasiswa SET  
	npm = '$npm',
	nama = '$nama',
	email = '$email',
	jurusan = '$jurusan',
	gambar = '$gambar'	
	WHERE id = $id
	";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}


function cari ($keyword) {
	$query = "SELECT * FROM mahasiswa 
				WHERE 
				nama LIKE '%$keyword%' OR 
				npm LIKE '%$keyword%' OR 
				email LIKE '%$keyword%' OR
				jurusan LIKE '%$keyword%'";

	return query($query);
}

function registrasi($data) {
	global $conn;

	$username = strtolower(stripcslashes($data["username"]));
	$password = mysqli_real_escape_string($conn, $data["password"]);
	$password2 = mysqli_real_escape_string($conn, $data["password2"]);

	// cek username sudah ada atau belum
	$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
	if (mysqli_fetch_assoc($result) ) {
		echo "<script>
				alert('Username sudah terdaftar!');
				</script>";
		return false;
	}

	// cek konfirmasi password
	if ( $password !== $password2 ) {
		echo "<script>
				alert('konfirmasi password tidak sesuai!');
				</script>";
		return false;
	}
	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);

	// tambahkan user baru ke database
	mysqli_query($conn, "INSERT INTO user VALUES('','$username',  '$password')");

	return mysqli_affected_rows($conn);
}


function kirimpesan($data) {
	global $conn;

	$name = strtolower(stripcslashes($data["nama"]));
	$email = mysqli_real_escape_string($conn, $data["email"]);
	$nohp = mysqli_real_escape_string($conn, $data["nohp"]);
	$kritik = mysqli_real_escape_string($conn, $data["kritik"]);

	// tambahkan user baru ke database
	mysqli_query($conn, "INSERT INTO contact VALUES(null,'$name',  '$email', '$nohp', '$kritik')");

	return mysqli_affected_rows($conn);
}






?>